import 'package:flutter/material.dart';
import 'package:pnstudio_app/core/constants/spacing.dart';
import 'package:pnstudio_app/core/widgets/section_title.dart';

class ChartPanel extends StatelessWidget {
  const ChartPanel({super.key});

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(Gaps.lg),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const SectionTitle(text: 'Gráfica P vs Rᵢ'),
            const SizedBox(height: Gaps.md),
            Container(
              height: 260,
              alignment: Alignment.center,
              child: const Text('Gráfica pendiente de integrar'),
            ),
          ],
        ),
      ),
    );
  }
}
