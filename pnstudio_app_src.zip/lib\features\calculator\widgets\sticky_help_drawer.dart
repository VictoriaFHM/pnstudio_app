import 'package:flutter/material.dart';

class StickyHelpDrawer extends StatelessWidget {
  const StickyHelpDrawer({super.key});

  @override
  Widget build(BuildContext context) {
    return Align(
      alignment: Alignment.bottomRight,
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: FloatingActionButton.extended(
          onPressed: () {
            showModalBottomSheet(
              context: context,
              showDragHandle: true,
              builder: (ctx) => Padding(
                padding: const EdgeInsets.all(20),
                child: ListView(
                  children: const [
                    Text(
                      '¿Para qué me sirve?',
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                    SizedBox(height: 12),
                    Text(
                      'Este cálculo te permite diseñar la carga RL para maximizar potencia '
                      'o cumplir un mínimo de potencia dentro de una eficiencia aceptable (k, c). '
                      'Mostraremos el intervalo factible y la recomendación según tu criterio.',
                    ),
                  ],
                ),
              ),
            );
          },
          label: const Text('¿Para qué me sirve?'),
          icon: const Icon(Icons.help_outline),
        ),
      ),
    );
  }
}
