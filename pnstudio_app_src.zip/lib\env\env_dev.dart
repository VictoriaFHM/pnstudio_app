class EnvDev {
  static const baseUrl = 'https://app-251108210925.azurewebsites.net';
}
