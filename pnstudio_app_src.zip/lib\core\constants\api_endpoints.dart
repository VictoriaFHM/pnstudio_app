// lib/core/constants/api_endpoints.dart
class ApiEndpoints {
  // Tu backend publicado en Azure:
  static const baseUrl = 'https://app-251108210925.azurewebsites.net';
  static const compute = '/api/Compute';
}
