import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:pnstudio_app/core/constants/spacing.dart';
import 'package:pnstudio_app/core/widgets/section_title.dart';
import 'package:pnstudio_app/data/models/compute_response.dart';

class RangesPanel extends StatelessWidget {
  final AsyncValue<ComputeResponse?> result;
  const RangesPanel({super.key, required this.result});

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(Gaps.lg),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const SectionTitle(text: 'Rangos / Recomendaciones'),
            const SizedBox(height: Gaps.md),
            switch (result) {
              AsyncData(value: final data) when data != null => _Results(
                data: data,
              ),
              AsyncError(:final error) => Text('Error: $error'),
              AsyncLoading() => const Center(
                child: Padding(
                  padding: EdgeInsets.all(16),
                  child: CircularProgressIndicator(),
                ),
              ),
              _ => const Text('Ingresa datos y presiona "Calcular".'),
            },
          ],
        ),
      ),
    );
  }
}

class _Results extends StatelessWidget {
  final ComputeResponse data;
  const _Results({required this.data});

  @override
  Widget build(BuildContext context) {
    final rows = <(String, String)>[
      ('Feasible', data.feasible ? 'Sí' : 'No'),
      ('RL min [Ω]', data.rlMin.toStringAsFixed(3)),
      ('RL max [Ω]', data.rlMax.toStringAsFixed(3)),
      ('Pmax [W]', data.pmax.toStringAsFixed(3)),
      ('η min', data.etaMin.toStringAsFixed(3)),
      ('η max', data.etaMax.toStringAsFixed(3)),
      if (data.recommendedRl != null)
        ('RL recomendado [Ω]', data.recommendedRl!.toStringAsFixed(3)),
      if (data.etaAtRec != null) ('η @rec', data.etaAtRec!.toStringAsFixed(3)),
      if (data.pAtRec != null) ('P @rec [W]', data.pAtRec!.toStringAsFixed(3)),
    ];

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        for (final (k, v) in rows)
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 6),
            child: Row(
              children: [
                SizedBox(
                  width: 180,
                  child: Text(
                    k,
                    style: const TextStyle(fontWeight: FontWeight.w600),
                  ),
                ),
                Text(v),
              ],
            ),
          ),
      ],
    );
  }
}
